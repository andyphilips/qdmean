library(testthat)
library(qdmean)

test_check("qdmean")
